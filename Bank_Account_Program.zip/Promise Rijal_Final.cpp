#include<iostream>
#include<iomanip>
#include<fstream>
#include<stdlib.h>
using namespace std;

struct ServiceAndOwed{
    float servCharges;
    float totalOwed;
};

class BankAccount{
	//access modifier
	protected:
		float balance;
		//Member variables.
		int numofDeposits;
		int numofWithdrawal;
		float annualInterestRate;
		float monthlyCharges;
		float serviceCharges; 
		//access modifier    
    public:
		BankAccount(float bal, float air){																						
			//Check for invalid input.
			if(bal < 0){
			    cout << "ERROR! BALANCE CANNOT START WITH A NEGATIVE AMOUNT!";
			}
        
			if(air < 0){
		        cout << "ERROR! INTEREST RATE CANNOT START WITH A NEGATIVE AMOUNT!";
	        }
			        	
	        //Set balance and annual interest rate to argumented values.
		        balance = bal;
		        annualInterestRate = air;
		        //Set the other variable to 0.
		        numofDeposits = 0;
			    numofWithdrawal = 0;
			    monthlyCharges = 0.0;
			    serviceCharges = 0.0;
    	}
    
		//Accessor functions.
		float getBalance(){
		    return balance; 
		}
		    
	    int getNumDeposits() {
		    return numofDeposits; 
		}
		    
	    int getNumWithdrawals(){
		    return numofWithdrawal; 
		}
		
	    float getAnnualIntRate(){
		    return annualInterestRate; 
		}
			
		float getMonthlyCharges(){
			return monthlyCharges; 
		}
    
		    //Mutator functions.
		void setAnnualIntRate(float air){
			//Validate input using while loop.
			while(air < 0){
			    cout << "\nNEGATIVE VALUE FOR ANNUAL INTEREST RATE ARE NOT ACCEPTED! ENTER AGAIN : ";
			    cin >> air;
			}
		    annualInterestRate = air;
		}
    
		void setMonthlyCharges(float mc){
		    	//Validate input using while loop.
		        while(mc < 0){
			            cout << "\nNEGATIVE VALUE FOR MONTHLY CHARGES ARE NOT ACCEPTED! ENTER AGAIN :";
			            cin >> mc;
		        	}
		        monthlyCharges = mc;
		}
    		
    		
    		
    	//virtual function so it can be redefined in the program (Polymorphism)
		virtual void makeDeposit(float d){
		    balance += d;
		    numofDeposits++;
		}
    		
		virtual void makeWithdrawal(float w){
		    balance -= w;
		    numofWithdrawal++;
		}
					    
		virtual void calcInt(){
			balance += (annualInterestRate/12.0)*balance;
		}
	    	
	    	
		virtual ServiceAndOwed monthlyProc(){
			balance -= monthlyCharges;
			calcInt();
			numofDeposits = 0;
			numofWithdrawal = 0;
			monthlyCharges = 0.0;
			serviceCharges = 0.0;
			ServiceAndOwed temp;
			return temp;
		}			
};


//inheritng from Main class Bank Account
class SavingsAccount : public BankAccount{
	private:

	    bool status;
	    bool ACTIVE;
	    bool INACTIVE;
	    
	public:
	    SavingsAccount(float b, float air) : BankAccount(b, air){
		//Check if balance is greater than 25 to set correct status.
		    ACTIVE = true;
		    INACTIVE = false;
		           
		    if(balance >= 25){
			    status = ACTIVE;
			}
			           
		    else{
			    status = INACTIVE;
			}
        	}
	    
		bool getStatus(){ 
		    return status; 
		}
		    
	    virtual void makeWithdrawal(float w){
		    //Check if status is active.
		    if(status == ACTIVE){
			    BankAccount::makeWithdrawal(w);
			    if(balance < 25)
			        status = INACTIVE;
			}
		    else{
			    //Otherwise, print error message then return.
			    cout << fixed << setprecision(2);
				cout << "WITHDRAWAL FAILED! "<<endl;
			    cout << "YOUR SAVINGS ACCOUNT IS INACTIVE :\nBALANCE: $";
			    cout << balance << endl;
			    }
		    }
		    
	    virtual void makeDeposit(float d){
		    if(status == INACTIVE){
			    if(d + balance >= 25){
				    BankAccount::makeDeposit(d);
				}
			    else{
				    cout << fixed << setprecision(2);
				    cout << "\nDEPOSIT FAILED! SAVINGS ACCOUNT WILL BE INACTIVE AFTER DEPOSIT!\n($" << balance << " + $" << d << " = $" << balance + d << ")\n";
				    return;
				}
			}
			else{
				BankAccount::makeDeposit(d);
			}
		}
					    		
	    virtual ServiceAndOwed monthlyProc(){
		    if(numofWithdrawal > 4){
			    serviceCharges += 1.0 * (numofWithdrawal - 4);
			    monthlyCharges += serviceCharges;
			}
		            
		    ServiceAndOwed temp;
		    temp.servCharges = serviceCharges;
		    temp.totalOwed = 0.0;
		    BankAccount::monthlyProc();
		    
			if(balance < 25){
			    status = INACTIVE;
			}
		    return temp;
		}
};


//inheritng from Main class Bank Account
class CheckingAccount:public BankAccount{
	private:
	       float owed;
	    
	public:
	    CheckingAccount(float b, float air) : BankAccount(b, air){
		    owed = 0.0;
		}
	       
	    //Accessor function.
	    float getAmountOwed() const{
		    return owed;
		}
	       
	    virtual void makeWithdrawal(float w){
		    if(w > balance){
				cout << fixed << setprecision(2);
			    cout << "\nWITHDRAWAL FAILED! \n YOUR CHECKING ACCOUNT IS :\nBALANCE: $";
			    cout << balance << endl;
			    balance -= 15.0;
			}
		    else{
			    BankAccount::makeWithdrawal(w);
			}
			}
	        
	    virtual ServiceAndOwed monthlyProc(){
		    serviceCharges += 5.0;
		    serviceCharges += 0.1 * numofWithdrawal;
		    monthlyCharges += serviceCharges;
		    
			ServiceAndOwed temp;
		    temp.servCharges = serviceCharges;
		    BankAccount::monthlyProc();
		    if(balance < 0){
		    	owed = 0 - balance;
		    	temp.totalOwed = owed;
		    	owed = 0;
		    }
			return temp;
		}
};

	




	
//main fucntion	
	
int main(){
	
	int choice;
	int menu;
			int accountNumber;
			char clientName[100];
			string address;
			string phonenumber;
			string email;
			float startingBalance;
			float annualRate;
	
loop:
	cout << "\n===================================================================================================================================================================================================================" << endl;
	cout << "\n\t\t\t\t\t\t\t\t\t\t\t\t\tABC BANK" << endl;
	cout << "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tCREATED BY - PROMISE RIJAL" << endl;
	cout << "\n===================================================================================================================================================================================================================" << endl;
	cout << "\n1. SAVINGS ACCOUNT" << endl;
	cout << "2. CHECKING ACCOUNT" << endl;
	cout << "3. LOG OUT" << endl;
	cout << "\nENTER YOUR CHOICE (1/2/3) : ";
	cin >> choice;
	while (choice != 1 && choice != 2 && choice != 3){
		
		cout << "\nGIVEN VALUE DO NOT MATCH THE CHOICE OPTIONS! TRY AGAIN!!! " << endl;
		cout << "===================================================================================================================================================================================================================" << endl;
		cout << "1. SAVINGS ACCOUNT" << endl;
		cout << "2. CHECKING ACCOUNT" << endl;
		cout << "3. LOG OUT" << endl;
		cout << "4. SEARCH CUSTOMER INFORMAITION :";
		cout << "\nENTER YOUR CHOICE (1/2/3/4) : ";
		cin >> choice;		
	}
	       
	switch (choice){
		case 1:{
			//Create a savings account.
						        
						        
			cout << "\nENTER ACCOUNT NUMBER 						: ";
			cin >> accountNumber;
			cin.ignore();
			cout << "ENTER CLIENT NAME						: ";
			cin.getline(clientName, 100);
			cout << "ENTER ADDRESS							: ";
			cin >> address;
			cout << "ENTER PHONENUMBER						: ";
			cin >> phonenumber;
			cout << "ENTER E-MAIL							: ";
			cin >> email;
			cout << "ENTER BEGINNING BALANCE OF SAVINGS ACCOUNT			: $";
			cin >> startingBalance;
			cout << "ENTER ANNUAL INTEREST RATE					: ";
			cin >> annualRate;
						        
			annualRate = annualRate/100;
						        
			SavingsAccount savAcc(startingBalance, annualRate);
						        
			//Set value of monthly processing charges and set it.
			float initProcessCharges;
				cout << "ENTER MONTHLY PROCESSING CHARGE					: $";
				cin >> initProcessCharges;
				savAcc.setMonthlyCharges(initProcessCharges);
						        

					float depos = 0; 
					float withdr = 0;
					float totalDepos = 0; 
					float totalWithdr = 0;
						        
					//Get all the monthly deposits.
					cout << "\nENTER THE DEPOSITS ONE BY ONE. WHEN FINSIHED ENTER -1		: ";
					cin >> depos;
					while(depos != -1){
						//Add deposit to total.
						totalDepos += depos;
						cout << fixed << setprecision(2);
						savAcc.makeDeposit(depos);
							            
						//Display data of savings account.
						cout << "\nBALANCE					: $" << savAcc.getBalance();
						cout << "\nNUMBER OF DEPOSITS			: " << savAcc.getNumDeposits();
						cout << "\nNUMBER OF WITHDRAWALS			: " << savAcc.getNumWithdrawals();
						cout << "\n\nENTER ADDITIONAL DEPOSIT AMOUNT, WHEN FINISHED ENTER -1 	: ";
						cin >> depos;
			        }
			        			
					//creating a file	
			        ofstream store;
			        store.open("savingsaccount.txt", ios::app);
			        	store << endl << accountNumber;
			        	store << endl << clientName;
			        	store << endl << address;
			        	store << endl << phonenumber;
			        	store << endl << email;
			        	store << endl << startingBalance;
			        	store << endl << savAcc.getNumDeposits();
						store << endl << totalDepos;
			        store.close();
								
			        			
					//method to take all the monthly withdrawals
					cout << "\nENTER WITHDRAWAL AMOUNT ONE BY ONE. WHEN FINISHED ENTER -1 	: ";
					cin >> withdr;
					while(withdr != -1){
					 //Add withdrawal to total.
					totalWithdr += withdr;
					cout << fixed << setprecision(2);
					savAcc.makeWithdrawal(withdr);
							            
						//display data of savings account
						cout << "\nBALANCE			: $" << savAcc.getBalance();
						cout << "\nNUMEBR OF DEPOSITS			: " << savAcc.getNumDeposits();
						cout << "\nNUMBER OF WITHDRAWALS			: " << savAcc.getNumWithdrawals();
						cout << "\n\nENTER ADDTIONAL WITHDRAWALS AMOUNT, WHEN FINISHED ENTER -1	: ";
						cin >> withdr;
					}
								
					//File creation and appending
					ofstream store1;
			        store1.open("savingsaccount.txt", ios::app);
			        	store1 << endl <<savAcc.getNumWithdrawals();
			        //closing the file
			        store1.close();	

					//Display
					cout << "\n\n\nCLIENT INFORMATION:" << endl;
					cout << "\nACCOUNT NUMBER					: " << accountNumber;
					cout << "\nCLIENT'S NAME					: " << clientName;
					cout << "\nADDRESS						: " << address;
					cout << "\nPHONE NUMBER					: " <<phonenumber;
					cout << "\nE-MAIL						: " << email; 
					cout << "\nBEGINING BALANCE 				: $" << startingBalance;
					cout << "\nNUMBER OF DEPOSITS 				: " << savAcc.getNumDeposits();
					cout << "\nTOTAL AMOUNT OF DEPOSITS 			: $" << totalDepos;
					cout << "\nNUMBER OF WITHDRAWALS 				: " << savAcc.getNumWithdrawals();
					cout << "\nTOTAL AMOUNT OF WITHDRAWALS 			: $" << totalWithdr;
					cout << "\nMONTHLY CHARGES 				: $" << initProcessCharges;
						        
					//Get the service charges in a structure and perform monthly processing.
					ServiceAndOwed temp = savAcc.monthlyProc();
					cout << "\nSERVICE FEES					: $" << temp.servCharges;
					cout << "\nTOTAL MONTHLY CHARGES				: $" << initProcessCharges + temp.servCharges;
						        
					//Display ending balance/
					cout << "\nENDING BALANCE					: $" << savAcc.getBalance();
							
					fstream doc; //file datatype and datamember
			        doc.open("savingsaccount.txt", ios::app);	//openeing file and appending
						doc <<	endl <<	totalWithdr;
						doc <<	endl <<	initProcessCharges;
						doc <<	endl <<	temp.servCharges;
						doc <<	endl << initProcessCharges + temp.servCharges;
						doc <<	endl <<	savAcc.getBalance() << endl;
			        doc.close();	//closing the file

					goto loop;
					break;
		}
		
		case 2:{
								
			int accountNumber;
			char clientName[100];
			string address;
			string phonenumber;
			string email;
			float startingbalance;
			float annualrate;
						        
				cout << "\nENTER ACCOUNT NUMBER 						: ";
				cin >> accountNumber;
				cin.ignore();
				cout << "ENTER CLIENT NAME						: ";
				cin.getline(clientName, 100);
				cout << "ENTER ADDRESS							: ";
				cin >> address;
				cout << "ENTER PHONENUMBER						: ";
				cin >> phonenumber;
				cout << "ENTER E-MAIL							: ";
				cin >> email;
				cout << "ENTER STARTING BALANCE OF CHECKING ACCOUNT			: $";
				cin >> startingbalance;
				cout << "ENTER ANNUAL INTEREST RATE					: ";
				cin >> annualrate;
						        
				//Update interest rate to be correct value because it is in %.
				annualrate = annualrate/100;
						        
				//Create a checking account object.
				CheckingAccount checkAcc(startingbalance, annualrate);
						        
				//Set value of monthly processing charges and set it.
				float initprocessCharges;
				cout << "ENTER MONTHLY PROCESSING CHARGES				: $";
				cin >> initprocessCharges;
				checkAcc.setMonthlyCharges(initprocessCharges);
						        
				//withdraw from this checking account.
				float Withdr = 0;
				float TotalWithdr = 0;

						        
				//Get the withdrawals with the same method.
				cout << "\nENTER WITHDRAWAL AMOUNT WHEN FINSHED ENTER -1 			: ";
				cin >> Withdr;
					while(Withdr != -1){
						//Add withdrawal to total.
						TotalWithdr += Withdr;
						cout << fixed << setprecision(2);
						checkAcc.makeWithdrawal(Withdr);
							            
						//Display data of savings account.
						cout << "\nBALANCE								: $" << checkAcc.getBalance();
						cout << "\nNUMBER OF DEPOSITS 						: " << checkAcc.getNumDeposits();
						cout << "\nNUMBER OF WITHDRAWALS						: " << checkAcc.getNumWithdrawals();
						cout << "\n\nENTER WITHDRAWAL AMOUNT OR ENTER -1 TO STOP			: ";
						cin >> Withdr;
					}
								
					ofstream store; //file datatype and datamember
			        store.open("checkingaccount.txt", ios::app); //creating a file and appending
			        	store << endl << accountNumber;
			        	store << endl << clientName;
			        	store << endl << address;
			        	store << endl << phonenumber;
			        	store << endl << email;
			        	store << endl << startingbalance;
			        	store << endl << checkAcc.getNumWithdrawals();
						store << endl << TotalWithdr;
			        store.close(); //closing the file
				        
					//Display
					cout << "\n\n\nCLIENT INFORMATION"<<endl;
					cout << "\nACCOUNT NUMBER							: " << accountNumber;
					cout << "\nCLIENT'S NAME							: " << clientName;
					cout << "\nADDRESS								: " << address;
					cout << "\nPHONE NUMBER							: " << phonenumber;
					cout << "\nE-MAIL								: " << email; 
					cout << "\nBEGINING BALANCE						: $" << startingbalance;
					cout << "\nNUMBER OF WITHDRAWALS						: $" << checkAcc.getNumWithdrawals();
					cout << "\nTOTAL AMOUNT OF WITHDRAWALS					: $" << TotalWithdr;
					cout << "\nINTIAL MONTHLY CHARGES 						: $" << initprocessCharges;
						        
					//Get the service charges and owed amount in the structure and perform monthly processing.
					ServiceAndOwed temp = checkAcc.monthlyProc();
					cout << "\nSERVICE FEES 							: $" << temp.servCharges;
					cout << "\nTOTAL MONTHLY CHARGES 						: $" << initprocessCharges + temp.servCharges;
					cout << "\nENDING BALANCE 							: $" << checkAcc.getBalance();
					cout << "\nCLIENT OWES TO BANK 						: $" << checkAcc.getAmountOwed();
					cout << endl;

					fstream store1;//file datatype and datamember
			        store1.open("checkingaccount.txt", ios::app);	//opening the file and appending
						store1 << endl <<	initprocessCharges;
						store1 << endl <<	temp.servCharges;
						store1 << endl << initprocessCharges + temp.servCharges;
						store1 << endl <<	checkAcc.getBalance();
						store1 << endl <<	checkAcc.getAmountOwed() << endl;
			        store1.close(); //closing the file
					goto loop;
					break;
		}
				
		case 3:{
		string option;
		
		cout << "\nARE YOU SURE YOU WANT TO LOG OUT? (Y/N) : ";
		cin >> option;
		while(option != "Y" && option != "N" && option != "y" && option != "n" ){
			cout << "\nENTER Y OR N!";
			cout << "\n===================================================================================================================================================================================================================" << endl;
			cout << "\nARE YOU SURE YOU WANT TO QUIT? (Y/N) : ";
			cin >> option;
		}
		
		if(option == "Y" || option == "y"){
			cout << "\nTHANK YOU FOR USING OUR PROGRAM!";
		break;
		}
		
		else{
			system("CLS");
			goto loop;
		break;
		}
			
		}
		
		case 4:{
			int askaccountnumber;
			
			cout << "ENTER ACCOUNT NUMBER :";
			cin >> askaccountnumber;
			
			if(askaccountnumber == accountnumber){
			
				ifstream store;
				store.open("savingsaccount.txt");
			        store >>  accountNumber;
			        store >>  clientName;
			        store >>  address;
			        store >>  phonenumber;
			        store >>  email;
			       	store >>  startingbalance;
			        store >>  checkAcc.getNumWithdrawals();
					store >>  TotalWithdr;
				store.close();
					cout << "\n\n\nCLIENT INFORMATION"<<endl;
					cout << "\nACCOUNT NUMBER							: " << accountNumber;
					cout << "\nCLIENT'S NAME							: " << clientName;
					cout << "\nADDRESS								: " << address;
					cout << "\nPHONE NUMBER							: " << phonenumber;
					cout << "\nE-MAIL								: " << email; 
					cout << "\nBEGINING BALANCE						: $" << startingbalance;
					cout << "\nNUMBER OF WITHDRAWALS						: $" << checkAcc.getNumWithdrawals();
					cout << "\nTOTAL AMOUNT OF WITHDRAWALS					: $" << TotalWithdr;
					cout << "\nINTIAL MONTHLY CHARGES 						: $" << initprocessCharges;
					cout << "\nSERVICE FEES 							: $" << temp.servCharges;
					cout << "\nTOTAL MONTHLY CHARGES 						: $" << initprocessCharges + temp.servCharges;
					cout << "\nENDING BALANCE 							: $" << checkAcc.getBalance();
					cout << "\nCLIENT OWES TO BANK 						: $" << checkAcc.getAmountOwed();
			}
			break;
		}
	}
return 0;
}
