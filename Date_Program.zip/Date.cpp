#include<iostream>
#include<iomanip>																														//iomanip headerfile to use setw() and setfill() functions
using namespace std;
class Date{
	
	private:																															//private access modifier which will be accessed only within the class
		
		int month;																														//local variable month
		int day;																														//local variable day
		int year;																														//local variable year
		char opt;																														//local variable option
		
		
	public:																																//public access modifier which will be accessed within the entire program
		
		void setmonth(int);																												//member function or mutator method used to set value after user input
		void setday(int);																												//member function or mutator method used to set value after user input
		void setyear(int);																												//member function or mutator method used to set value after user input
		void setopt(char);																												//member function or mutator method used to set value after user input
		
	
		Date();																															//default constructor
		
		
		Date operator ++ ();																											//Unary Prefix increment operator overloading
		Date operator ++ (int);																											//Unary Postfix increment operator overloading
		Date operator -- ();																											//Unary Prefix decrement operator  overloading
		Date operator --(int);																											//Unary Postfix decrement operator overloading
		Date operator -(Date);																											//Binary Operator overloading
		friend ostream &operator <<(ostream &, Date &);																					//Insertion operator overloading
		
		
		void incrementordecrement();																									//display function
		void Displaydifference();																										//display function
		void Displayaddorsub();																											//display function
};



void Date::setmonth(int aMonth){																										//calling member functions or mututor methods outside class
	month = aMonth;
}


void Date::setday(int aDay){
	day = aDay;
}


void Date::setyear(int aYear){
	year = aYear;
}


void Date::setopt(char aOpt){
	
	opt = aOpt;
}




Date::Date(){																																		//default constructor called outside class
	
	month = 0;
	day = 0;
	year = 0;
}




Date Date::operator ++(){																															//Unary prefix increment operator called outside class
	Date temp;
	temp.day = ++day;
	return temp;
	
	
}


Date Date::operator ++(int){																														//Unary postfix increment operator called outside class
	Date temp;
	temp.day = day++;
	return temp;
}


Date Date::operator --(){																															//Unary prefix decrement operator called outside class
	Date temp;
	temp.day = --day;
	return temp;
}


Date Date::operator --(int){																														//Unary postfix decrement operator called outside class
	Date temp;
	temp.day = day--;
	return temp;
}


Date Date::operator -(Date d){																														//Binary operator called outside class

Date temp;
int count;
	int days[] = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

	
	temp.month = month - d.month;
	temp.day = day - d.day;
	temp.year = year - d.year;
	if(temp.year>4)
	{
		count = temp.year/4;
	}
	else{
		count = 1;
	}
	if(year%4==0 || d.year%4==0) {
		temp.year = (temp.year*365 + count);
		
		if(temp.month<0){
			temp.month +=12;
			for(int j = 1; j<= temp.month; j++){
				temp.month += days[temp.month];
			}	
		}
		
		if(temp.day<0){
			temp.month -= 12; 
			temp.day = days[temp.month];
		}
	}
		
		
	else{
		
		temp.year = temp.year*365;
		
			if(temp.month<0){
				temp.month +=12;
				for(int j = 1; j<= temp.month; j++){
					temp.month += days[temp.month];
				}	
			}
		
			if(temp.day<0){
				temp.month -= 12; 
				temp.day = days[temp.month];
			}	
	}
	return temp;
}


ostream &operator <<(ostream &out, Date &d){																												//friend function called outside class
	out << endl << setfill('0') << setw(2) << d.month << "/" << setfill('0') << setw(2) << d.day << "/" << setfill('0') << setw(2) << (d.year%100) << endl;
	static string names[]={"", "January ", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};	//static keyword used so that it will be shared by all the objects of the class
	out << names[d.month] <<" "<< setfill('0') << setw(2) << d.day << "," <<" "<<d.year << endl;
	out << setfill('0') << setw(2) << d.day <<" "<< names[d.month]<<","<<" "<< d.year << endl;
	return out;
}





void Date::incrementordecrement(){																													//display function for d2 object
		
	int days[] = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};	
	
		if(day>days[month]){
			month = month + 1;
			if(year%4==0)
			{
				days[2] = 29;
			}
			day = day / days[month-1];
		}
		if(day<1){
			month = month - 1;
			if(year%4==0)
			{
				days[2] = 29;
			}
			day = day + days[month];
		}
		
		if(month>12)
		{
			year = year+1;
			month = month/12;
		}
		if(month<1){
			year = year-1;
			month = month+12;
			day = day+31;
		}
	}


void Date::Displaydifference(){																														//display function for d5 object
		
		cout << endl << (year+month+day) << " NO. OF DAYS ARE BETWEEN GIVEN TWO DATES." << endl;	
}


void Date::Displayaddorsub(){																														//display function for d7 object
	int days[] = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};																				
	
	if(opt == '+'){
		day++;
		if(day>days[month]){
			month = month + 1;
			if(year%4==0)
			{
				days[2] = 29;
			}
			day = day / days[month-1];
		}
		
		if(month>12)
		{
			year = year+1;
			month = month/12;
		}	
	cout << endl <<"THE DATE AFTER INCREMENT";
	}
	
	
	else {
		day--;
		if(day<1){
			month--;
			if(year%4==0)
			{
				days[2] = 29;
			}
			day = day + days[month];
		}
	
		if(month<1){
			year = year-1;
			month = month+12;
			day = day+31;
		}
	cout << endl <<"THE DATE AFTER DECREMENT";
	}
}
	


int main(){
	
	char smiley = 1;
	int choice;
	
		cout <<"\n\t\t\t\t\t\t\t\t\t\t\tHELLO! WELCOME TO MY PROGRAM" << endl;
		cout <<"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tCREATED BY - PROMISE RIJAL" <<endl;
		cout << "\n===================================================================================================================================================================================================================" << endl;
		cout <<"OUTPUT FORMAT:" << endl << endl;
		cout << "\tMONTH(INTEGER) / DAY(INTEGER) / YEAR" << endl;
		cout << "\tMONTH(STRING) DAY(INTGER), YEAR" << endl;
		cout << "\tDAY(INTEGER) MONTH(STRING), YEAR" << endl;	
		cout << "\n===================================================================================================================================================================================================================" << endl;	
		cout <<"NOTE :" << endl;
		cout <<"\tMONTH SHOULD BE INTEGER VALUE BETWEEN 1 AND 12" << endl;
		cout <<"\tDAY SHOULD BE BETWEEN 1 AND 31 " <<endl;
		cout << "\n===================================================================================================================================================================================================================" << endl;
		cout << "IN THIS PROGRAM YOU WILL BE ABLE TO:\n" << endl;
		cout << "\t1. DISPLAY THE GIVEN INPUT DATA AS IN THE FORMAT.\n" << endl;
		cout << "\t2  i.DISPLAY THE DAY AFTER PRE AND POST INCREMENT AND PRE AND POST DECREMENT.\n\t  ii.DISPLAY THE NUMBER OF DAYS BETWEEN TWO DATES.\n" << endl;
		cout << "\t3. DISPLAY THE DATE AFTER YOU INCREMENT OR DECREMENT." << endl;
		cout << "\n===================================================================================================================================================================================================================" << endl;
		cout << "\nENTER YOUR CHOICE (1/2/3) : ";
		cin >> choice;	
		while(choice != 1 && choice !=2 && choice != 3){
			cout << "\nGIVEN VALUES DO NOT MATCH THE DESCRIPTION! TRY AGAIN!!! " << smiley << endl;
			cout << "===================================================================================================================================================================================================================" << endl;
			cout << "\nENTER YOUR CHOICE (1/2/3) : ";
			cin >> choice;	
		}
	
	switch(choice){																																	//switch case to choose what they want to display
	
	case 1:{
		Date d1;																																	//define d1 object of date class
		
		int d1month;																																//local variable for month;
		int d1day;																																	//local variable for day;
		int d1year;																																	//local variable for year;
		//get value of date to display in format
		cout << "\n1. DISPLAY THE DATE IN GIVEN FORMAT" << endl;
		cout << "\nENTER THE DATE(mm/dd/yyyy) = ";
		cin >> d1month;
		cin >> d1day;
		cin >> d1year;
		
		while((d1month != 1 && d1month !=2 && d1month !=3 && d1month !=4 && d1month !=5 && d1month !=6 && d1month !=7 && d1month !=8 && d1month !=9 && d1month !=10 && d1month !=11 && d1month !=12) || (d1day<1 || d1day>31)){
			cout << "\nGIVEN VALUES DO NOT MATCH THE DESCRIPTION! TRY AGAIN!!! " << smiley << endl;
			cout << "===================================================================================================================================================================================================================" << endl;
			cout << "\nENTER THE DATE(mm/dd/yyyy) =  ";
			cin >> d1month;
			cin >> d1day;
			cin >> d1year;
		}
		//store the month, day and year in d1 object
		d1.setmonth(d1month);
		d1.setday(d1day);
		d1.setyear(d1year);
		
		//display the stored data members calling insertion operator
		cout << d1;
		
		break;
	}
	
	
	case 2:{
		Date d2;																																			//define d2 object of date class
		
		int d2month;																																		//local variable for month
		int d2day;																																			//local variable for day
		int d2year;																																			//local variable for year
		
		//get the values
		cout << "\n2. i.DISPLAY THE DAY AFTER PRE AND POST INCREMENT AND PRE AND POST DECREMENT" << endl <<endl;
		cout << "ENTER THE DAY (mm/dd/yyyy):";
		cin >> d2month;
		cin	>> d2day;
		cin >> d2year;
		
		while((d2month<1 || d2month>12) || (d2day<1 || d2day>31)){
			cout << "\nGIVEN VALUES DO NOT MATCH THE DESCRIPTION! TRY AGAIN!!!" << smiley << endl;
			cout << "===================================================================================================================================================================================================================" << endl;
			cout << "ENTER THE DAY (mm/dd/yyyy):";
			cin >> d2month;
			cin >> d2day;
			cin >> d2year;			
		}
		//store the values
		d2.setmonth(d2month);
		d2.setday(d2day);
		d2.setyear(d2year);
		
		++d2;																																				//prefix increment operator called
		cout << "\nDAY AFTER PRE INCREMENT : " << endl;
		d2.incrementordecrement();																															//calling the incrementordecrement function for calculations
		cout << d2;																																			//display the output
		d2++;																																				//postfix increment operator called
		cout << "\nDAY AFTER POST INCREMENT : " << endl;																									
		d2.incrementordecrement();																															//calling the incrementordecrement function for calculations
		cout << d2;																																			//display the output
		
		--d2;																																				//pretfix decrement operator called
		cout << "\nDAY AFTER PRE DECREMENT : " << endl;
		d2.incrementordecrement();																															//calling the incrementordecrement function for calculations
		cout << d2;																																			//display the output
		d2--;																																				//pretfix decrement operator called
		cout << "\nDAY AFTER POST DECREMENT : " << endl;
		d2.incrementordecrement();																															//calling the incrementordecrement function for calculations		
		cout << d2;																																			//display the output
		
		
		
		Date d3;																																			//define d3 object of date class
		
		int d3month;																																		//local variable for month
		int d3day;																																			//local variable for day
		int d3year;																																			//local variable for year
		cout << "\n2. ii.DISPLAY THE NUMBER OF DAYS BETWEEN TWO DATES, NOTE : (FIRST DATE > SECOND DATE)" << endl <<endl;
		cout << "\nENTER THE FIRST DATE(mm/dd/yyyy) = ";
		cin >> d3month;
		cin >> d3day;
		cin >> d3year;
		
		//Get the first date
		while((d3month < 1 || d3month >12) || (d3day<1 || d3day>31)){
			cout << "\nGIVEN VALUES DO NOT MATCH THE DESCRIPTION! TRY AGAIN!!!" << smiley << endl;
			cout << "===================================================================================================================================================================================================================" << endl;
			cout << "\nENTER THE FIRST DATE(mm/dd/yyyy) = ";
			cin >> d3month;
			cin >> d3day;
			cin >> d3year;
			
		}
		//store the values entered
		d3.setmonth(d3month);
		d3.setday(d3day);
		d3.setyear(d3year);
		
		
		Date d4;																																		//define d4 object
		//Get the second date																															
		int d4month;																																	//local variable for month
		int d4day;																																		//local variable for day
		int d4year;																																		//local variable for year
		//get values of the date	
		cout << "\nENTER THE SECOND DATE(mm/dd/yyyy) = ";
		cin >> d4month;
		cin >> d4day;
		cin >> d4year;
		
		while((d4month < 1 || d4month >12) || (d4day<1 || d4day>31)) {
			cout << "\nGIVEN VALUES DO NOT MATCH THE DESCRIPTION! TRY AGAIN!!! " << smiley << endl;
			cout << "===================================================================================================================================================================================================================" << endl;
			cout << "\nENTER THE SECOND DATE(mm/dd/yyyy) = ";
			cin >> d4month;
			cin >> d4day;
			cin >> d4year;
		}
		//store the value entered
		d4.setmonth(d4month);
		d4.setday(d4day);
		d4.setyear(d4year);
		
		
		Date d5;																														//define d5 object from date class
		//d4 object is subtracted from d3 whose resultant value is stored in d5 object
		d5 = d3 - d4;
		d5.Displaydifference();																											//display function called to display the resultant value of d5 object
		
		break;
		}
	
	
	case 3:{
		Date d6;																																					//define d6 object
		
		int d6month;																																				//local variable for month
		int d6day;																																					//local variable for day
		int d6year;																																					//local variable for year
		char d6opt;																																					//local variable for the user to choose wether to increment or decrement
		//get value of the date
		cout << "\n3. DISPLAY THE DATE AFTER YOU INCREMENT OR DECREMENT" << endl;
		cout << "\nDO YOU WANT TO INCREMENT OR DECREMENT THE DATE ( + / - ) = " << endl;
		cin >> d6opt;
		cout << "\nENTER THE DATE(mm/dd/yyyy) = ";
		cin >> d6month;
		cin >> d6day;
		cin >> d6year;
		
		while((d6month < 1 || d6month >12) || (d6day<1 || d6day>31) || (d6opt != '+' && d6opt != '-')){
			cout << "\nGIVEN VALUES DO NOT MATCH THE DESCRIPTION! TRY AGAIN!!! " << smiley << endl;
			cout << "===================================================================================================================================================================================================================" << endl;
			cout << "\nDO YOU WANT TO INCREMENT OR DECREMENT THE DATE ( + / - ) = " << endl;
			cin >> d6opt;
			cout << "\nENTER THE DATE(mm/dd/yyyy) = ";
			cin >> d6month;
			cin >> d6day;
			cin >> d6year;
		}
		//store value of date
		d6.setopt(d6opt);		
		d6.setmonth(d6month);
		d6.setday(d6day);
		d6.setyear(d6year);
		
		d6.Displayaddorsub();																																		//calling the displayaddorsub function for calculations
		cout << d6;																																					//display the result calling insertion operator
		
		break;
	}
	}
	return 0;
}
