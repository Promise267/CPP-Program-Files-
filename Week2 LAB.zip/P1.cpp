#include<iostream>
using namespace std;
int main()
{
	double celsius;
	double fahrenheit;
	char character = 248;
	
	cout << "ENTER THE TEMPLERATURE IN CELSISUS (" << character <<  "C) :" << endl;
	cin >> celsius;
	
	fahrenheit = (9 / 5 ) * celsius + 32;
	
	cout << "THE TEMPARATURE IN FAHRENHEIT IS = " << fahrenheit << character << "F" << endl;
	return 0;
}
