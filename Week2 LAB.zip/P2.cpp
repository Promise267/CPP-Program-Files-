#include<iostream>
using namespace std;
int main()
{
	char choice, character = 36;
	int totalcostofpine, totalcostofoak, totalcostofmahogany, numberofchoice;
	int costofpine = 100;
	int *acostofpine = &costofpine;
	int costofoak = 225;
	int *acostofoak = &costofoak;
	int costofmahogany = 310;
	int *acostofmahogany = &costofmahogany;
	
	cout<< "=========================================================================" << endl;
	cout << "		Italian Woods Furniture Company" << endl;
	cout << "=========================================================================" << endl;
	cout << "Enter P for pine, O for Oak or M for Mahogany : ";
	cin >> choice;
	cout << "How many tables do you want: ";
	cin >> numberofchoice;
	while(choice != 'P' && choice != 'O' && choice != 'M')
	{
		cout << "=========================================================================" << endl;
		cout << "INVALID OPTION ENTERED, TRY AGAIN!" <<endl;
		cout << "=========================================================================" << endl;
		cout << "Enter P for pine, O for Oak or M for Mahogany : ";
		cin >> choice;
		cout << "How many tables do you want: ";
		cin >> numberofchoice;
	}
	switch(choice)
	{
		case 'P':
			{
				totalcostofpine = numberofchoice * (*acostofpine);
				cout << "\nWood Selected\tNo.of tables\tTotal cost" << endl;
				cout << "---------------\t------------\t--------------" << endl;
				cout << "Pine" << "\t\t" << numberofchoice << "\t\t" << character << totalcostofpine << endl << endl;
				cout<< "Thank you for visiting us." << endl;
				cout << "=========================================================================" << endl;
				break;	
			}
		case 'O':
			{
				totalcostofoak = numberofchoice * (*acostofoak);
				cout << "\nWood Selected\tNo.of tables\tTotal cost" << endl;
				cout << "---------\t------------\t---------" << endl;
				cout << "Oak" << "\t" << numberofchoice << "\t" << character << totalcostofpine << endl << endl;
				cout<< "Thank you for visiting us." << endl;
				cout << "=========================================================================" << endl;
				break;
			}
		case 'M':
			{
				totalcostofmahogany = numberofchoice * (*acostofmahogany);
				cout << "\nWood Selected\tNo.of tables\tTotal cost" << endl;
				cout << "---------\t------------\t---------" << endl;
				cout << "Mahogany" << "\t" << numberofchoice << "\t\t" << character << totalcostofmahogany << endl << endl;
				cout << "Thank you for visiting us." << endl;
				cout << "=========================================================================" << endl;
				break;
			}
	}
	return 0;
}
