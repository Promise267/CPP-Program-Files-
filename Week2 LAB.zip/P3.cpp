#include<iostream>
using namespace std;
struct Apartment{
	int numberofbedrooms;
	int numberofbaths;
	double monthlyrent;
	Apartment(int aNumberOfBedrooms, int aNumberOfBaths, double aMonthlyRent)
	{	
		numberofbedrooms = aNumberOfBedrooms;
		numberofbaths = aNumberOfBaths;
		monthlyrent = aMonthlyRent;
	}
};
int main()
{
	char character = 36;
	int noofbedroom, noofbathroom;
	cout<< "	HELLO! WELCOME TO OUR PROGRAM TO ENTER YOUR DESIRED APARTMENT ROOM COMBINATION" << endl;
	cout << "==================================================================================================" << endl;
	cout << "\nEnter number of bedrooms (MIN = 1, MAX = 3 ) : ";
	cin >> noofbedroom;
	cout <<"Enter number of bathrooms (MIN = 1, MAX = 2 ) : ";
	cin >> noofbathroom;
	while((noofbedroom <=0 && noofbedroom >=4) && (noofbathroom <=0 && noofbathroom >=3))
START:
	{
		cout << "\nTRY AGAIN! THE GIVEN INTEGER VALUE DOES NOT MEET THE GIVEN CONDITION" << endl;
		cout << "==================================================================================================" << endl;
		cout << "Enter number of bedrooms (MIN = 1, MAX = 3 ) : ";
		cin >> noofbedroom;
		cout <<"Enter number of bathrooms (MIN = 1, MAX = 2 ) : ";
		cin >> noofbathroom;
	}
	if(noofbedroom == 1 && noofbathroom == 1)
	{
		Apartment a1(1, 1, 650);
		{
		cout << "\nNumber Of Bedrooms - " << a1.numberofbedrooms << endl;
		cout << "Number Of Bathrooms - " << a1.numberofbaths << endl;
		cout << "Monthly Rent - " << character << a1.monthlyrent <<endl;
		}
	}
	else if(noofbedroom == 1 && noofbathroom == 2)
	{
		Apartment a2(1, 2, 0);
		{
		cout << "\nNumber Of Bedrooms - " << a2.numberofbedrooms << endl;
		cout << "Number Of Bathrooms - " << a2.numberofbaths << endl;
		cout << "Monthly Rent - " << character << a2.monthlyrent <<endl;
		cout << "Sorry! Given Apartment Combination is not Available.";
		}
	}
	else if(noofbedroom == 2 && noofbathroom == 1)
	{
		Apartment a3(2, 1, 829);
		{
		cout << "\nNumber Of Bedrooms - " << a3.numberofbedrooms << endl;
		cout << "Number Of Bathrooms - " << a3.numberofbaths << endl;
		cout << "Monthly Rent - " << character << a3.monthlyrent <<endl;
		}
	}
	else if(noofbedroom == 2 && noofbathroom == 2)
	{
		Apartment a4(2, 2, 925);
		{
		cout << "\nNumber Of Bedrooms - " << a4.numberofbedrooms << endl;
		cout << "Number Of Bathrooms - " << a4.numberofbaths << endl;
		cout << "Monthly Rent - " << character << a4.monthlyrent <<endl;

		}
	}
	else if(noofbedroom == 3 && noofbathroom == 1)
	{
		Apartment a5(3, 1, 0);
		{
			cout << "\nNumber Of Bedrooms - " << a5.numberofbedrooms << endl;
			cout << "Number Of Bathrooms - " << a5.numberofbaths << endl;
			cout << "Monthly Rent - " << character << a5.monthlyrent <<endl;
			cout << "\nSorry! Given Apartment Combination is not Available.";
		}
	}
	else if(noofbedroom == 3 && noofbathroom == 2)
	{
		Apartment a6(3, 2, 1075);
		{
		cout << "\nNumber Of Bedrooms - " << a6.numberofbedrooms << endl;
		cout << "Number Of Bathrooms - " << a6.numberofbaths << endl;
		cout << "Monthly Rent - " << character << a6.monthlyrent <<endl;
		}
	}
	else
	{
		goto START;
	}
	return 0;
}
