#include<iostream>
using namespace std;
class Employee
{
	public:
		string name;
		int idNumber;
		string department;
		string position;
		void EmployeeDisplayInfo()
		{
			cout << "\nName : " << name << endl;
			cout << "ID Number : " << idNumber << endl;
			cout << "Department : " << department << endl;
			cout << "Position : " << position << endl;
		}
		Employee(string aName, int aidNumber, string aDepartment, string aPosition)
		{
			name=aName;
			idNumber=aidNumber;
			department=aDepartment;
			position=aPosition;
		}
};
int main()
{
	Employee e1("Susan Meyers", 47899, "Accounting", "Vice President");
	e1.DisplayInfo();
	Employee e2("Mark Jones", 39119, "IT", "Programmer");
	e2.DisplayInfo();
	Employee e3("Joy Rogers", 81774, "Manufacturing", "Engineer");
	e3.DisplayInfo();
		
	return 0;
}
