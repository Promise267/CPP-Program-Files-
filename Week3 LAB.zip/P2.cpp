#include<iostream>
#include<string.h>
using namespace std;

class Car
{
	private:
	
	int YearModel;
	string make;
	int speed;
	
	public:
		int getmodel()
		{
			return YearModel;
		}
		string getmake()
		{
			return make;
		}
		int getspeed()
		{
			return speed;
		}
		Car(int y, string m)
		{
			YearModel=y;
			make=m;
			speed=0;
		}
		
		void accelerate();
		void brake();
};

void Car::accelerate()
{
	speed+=5;
}

void Car::brake()
{
	speed-=5;
}


int main()
{
	Car car(2012,"Tesla Model S");
	cout<<"================================================="<<endl;
	cout<<"The model is from "<<car.getmodel()<<" and name is "<<car.getmake()<<"."<<endl;
	cout<<"================================================="<<endl;
	int accleration,brake;
	accleration=5;

	for(int i=1; i<=accleration; i++)
	{
		cout<<"The speed is increasing = ";
		car.accelerate();
		cout<<car.getspeed()<<endl;
	}
	cout<<"============================"<<endl;
	
	for(int i=1; i<=accleration; i++)
	{
		cout<<"The speed is decreasing = ";
		car.brake();
		cout<<car.getspeed()<<endl;
	}
	
	return 0;
}
