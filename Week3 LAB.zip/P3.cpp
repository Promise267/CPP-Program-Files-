#include<iostream>
#include<string.h>
using namespace std;
class personalinfo{
	
private:
	
	string name;
	string address;
	int age;
	string phonenumber;
	
public:
	
	void setname(string aName){
		name = aName;
	}
	string getname(){
		return name;
	}
	
	
	void setaddress(string aAddress){
		address = aAddress;
	}
	string getaddress(){
		return address;
	}
	
	
	void setage(int aAge){
		age = aAge;
	}
	int getage(){
		return age;
	}
	
	
	void setphonenumber(string aPhonenumber){
		phonenumber = aPhonenumber;
	}
	string getphonenumber(){
		return phonenumber;
	}
	
	
	void display(){
		cout << "\nName = " << name << endl;
		cout << "Address = " <<  address << endl;
		cout << "Age = " << age << endl;
		cout << "Phonenumber = " << phonenumber << endl;
	} 
	personalinfo(string aName, string aAddress, int aAge, string aPhonenumber){
		name = aName;
		address = aAddress;
		age = aAge;
		phonenumber = aPhonenumber;
	};
};


int main()
{
	personalinfo p1("Promise", "Shorakhutte", 19, "+977-9840-710-520");
	p1.display();
	
	personalinfo p2("Parashuram", "Shorakhutte", 50, "+977-9851-026-261");
	p2.display();
	
	personalinfo p3("Pratik", "Budanilakantha", 19, "+977-9841-357-743");
	p3.display();
	
	return 0;
}
