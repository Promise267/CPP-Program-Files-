#include<iostream>
#include<string.h>
using namespace std;
class retailitem{
	
private:
	
	string description;
	int unitsOnHand;
	double price;
	
public:
	
	void setdescription(string aDescription){
		description = aDescription;
	}
	string getdescription(){
		return description;
	}
	
	
	void setunitsOnHand(int aUnitsOnHand){
		unitsOnHand = aUnitsOnHand;
	}
	int getunitsOnHand(){
		return unitsOnHand;
	}
	
	
	void setprice(double aPrice){
		price = aPrice;
	}
	double getprice(){
		return price;
	}
	
	
	void display(){
		cout << "\nDescription = " << description << endl;
		cout << "Units On Hand = " << unitsOnHand << endl;
		cout << "Price = " << price << endl;
	}
	
	
	retailitem(string aDescription, int aUnitsOnHand, double aPrice){
		description = aDescription;
		unitsOnHand = aUnitsOnHand;
		price = aPrice;
	}
};
int main()
{
	retailitem r1("Jacket", 12, 59.95);
	r1.display();
	retailitem r2("Designer Jacket", 40, 34.95);
	r2.display();
	retailitem r3("Shirt", 20, 24.95);
	r3.display();
	
	
	return 0;
}
