#include<iostream>
using namespace std;

class Circle
{
	private:
	
	double radius;
	double pi;
	
	public:
		
		Circle()
		{
			radius=0.0;
		}
		Circle(int R)
		{
			radius = R;
		}
		double setRadius()
		{
			cin>>radius;
			pi = 3.14159;
		}
		double getRadius()
		{
			return radius;
		}
		double getArea()
		{
			return pi * radius * radius;
		}
		double getDiameter()
		{
			return 2 * radius;
		}
		double getCircumference()
		{
			return 2 * pi * radius;
		}
};

int main()
{
	// Input taking
	cout<<"Enter the radius in cm : ";
	Circle r(5);
	r.setRadius();
	cout<<"===========================================" << endl;
	cout<<"The radius         is  = "<<r.getRadius()<<" cm."<<endl;
	cout<<"The area           is  = "<<r.getArea()<<" square cm."<<endl;
	cout<<"The diameter       is  = "<<r.getDiameter()<<" cm."<<endl;
	cout<<"The circumference  is  = "<<r.getCircumference()<<" cm."<<endl;
	cout<<"===========================================" << endl;

	return 0;
}
