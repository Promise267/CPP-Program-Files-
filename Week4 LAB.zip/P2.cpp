#include<iostream>
using namespace std;
// Employee class declaration
class Employee
{
    private:
        int empID;
        string name;
    public:
        Employee() //  default constructor
        {
            empID = 1000;
            name = "Ramesh";
        }
        //************************************************
        // Declaration of one parameter constructor. *
        //************************************************
        Employee(int id)  
        {
            empID = id;
        }
        //************************************************
        // Declaration of two parameter constructor. *
        //************************************************
        Employee(int id, string s1) 
        {
            empID = id;
            name = s1;
        }
        //****************************************************
        // getEmp return the value in empID. *
        //****************************************************
        int getEmpID()
        {
            return empID;
        }
        //****************************************************
        // setEmpID assigns value to the empID. *
        //****************************************************
        void setEmpID(int id) // setter - also known as Mutators
        {
            empID = id;
        }
        //****************************************************
        // getName returns the value in name member. *
        //****************************************************
        string getName()
        {
            return name;
        }
        //****************************************************
        // setName assigns a value to the name member. *
        //****************************************************
        void setName(string s)
        {
            name = s;
        }
        //****************************************************
        // Displays the value stored in empID and name when called *
        //****************************************************
        void display()
        {
            cout << "Employee ID = " << empID<< endl;
            cout << "Employee Name = " << name << endl;
        }
    
};
//************************************************
// Function main                                 *
//************************************************

int main()
{
    Employee e; // created an instance/ object of Employee type
                // default constructor is called
    e.display(); // calling
    Employee e1; // default constructor is called
    e1.setEmpID(2000); //stores EmpID in e1 object
    e1.setName("Ashish"); // store the name in e1 object
    e1.display(); //display function for e1 object is called
    
    // parameterized constructor will be called
    Employee e2(3000); 
    e2.setName("Ram");//stores name in e2 object
    e2.display(); //display function for e2 object is called
    // parameterized constructor with two parameters called
    Employee e3(4000,"Susma"); 
    e3.display(); //display function for e3 object is called
    
    return 0;
}

