#include<iostream>
#include<string.h>
using namespace std;
//Student class declaration.
class Student
{
    int roll;
    string name;
    public:
        
        Student(int roll = 0, string name = "TBC")
        {
            Student::roll = roll;
            Student::name = name;
        }
        //*****************************************************
        //copy constructor where parameter is an object. *
        //*****************************************************
        Student(Student &std) 
        {
            cout << "Copy constructor called\n";
            roll = std.roll;
            name = std.name;
        }
//***************************************************************************
//Display function to display roll and name when the function is called. *
//***************************************************************************
        void display()
        {
            cout << "Student roll number = " << roll << endl;
            cout << "Student name = " << name << endl;
        }
    
};
//************************************************
// Function main 
//************************************************

int main()
{
    Student s1;  // default 
    s1.display(); // display function for s1 is called
    
    Student s2(1000,"Ram");  // parameterized
    s2.display(); // display function for s2 is called
    
    Student s3(s2); // calling copy constructor 
                //: parameter is an object
    
    cout << "Value stored in S3 are : \n";
    s3.display(); // display function for s3 is called
    return 0;
}

