#include<iostream>
using namespace std;

//Car class delaration
class Car{
	private:	
	static int count;

	public:
		
	Car(){														//Constructor
		count++;												//Postincrement
		cout << "CAR " << count << " OBJECT CONSTRUCTED" << endl;
	}
	
//******************************************************************************************	
//getCount returns the value in count member of static data type
//******************************************************************************************


	static int getCount(){										//function for static data memeber int count
		
		return count;			
	}
	
	const ~Car(){												//Destructor	
		cout << "CAR "<<count<<" OBJECT DESTRUCTED" <<endl;
		count--;												//Postdecrement
	}
};

//******************************************************************************************
//static count member value declaration outside the class	
//******************************************************************************************
	
int Car::count = 0;	

//******************************************************************************************
//Funtion main
//******************************************************************************************

int main(){
	
	cout << "CONSTRUCTOR : "<< endl;
	Car c[5];			//Define instance of Car class using array
	
	for (int i=0; i<5; i++){
		
		//Constructor is called
		c[5].getCount();
	}
	
	cout << endl << "DESTRUCTOR : " << endl;			
	//Destructor is called
	return 0;
}
