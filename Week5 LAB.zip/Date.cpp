#include<iostream>
using namespace std;
//Date class delaration
class Date{
	private:
		int month;
		int day;
		int year;
	public:
		Date()												//default constructor
		{
			month = 1;
			day = 1;
			year = 2000;
		}
		
		Date(int aMonth, int aDay, int aYear)				//parameterized constructor
		{
			month = aMonth;
			day = aDay;
			year = aYear;			
		}
		
		void Display()										//display function for object
		{
			cout << endl << "Month = " << month <<endl;
			cout << "Day = " << day <<endl;
			cout << "Year = " << year << endl;
		}
};
//******************************************************************************************
//Funtion main
//******************************************************************************************
int main()
{
	Date d1,d2(5,8,2002);
	cout << "Default Constructor";
	d1.Display();
	cout << "\nParameterized Constructor";
	d2.Display();
	return 0;
}
