#include<iostream>
#include<string.h>
using namespace std;
//Person class delaration
class Person{
	private:
		string lname;
		string fname;
		string zcode;
	public:
		Person()														//default constructor with no value initialised
		{
			lname = "";
			fname = "";
			zcode = "";			
		}
		
		Person(string alname, string afname, string azcode)				//parameterised constructor
		{
			lname = alname;
			fname = afname;
			zcode = azcode;
		}
		
		void display()													//display function for objects
		{
			if(lname[0] == '\0' && fname[0] == '\0' && zcode[0] == '\0'){
				cout << endl << "Last Name : " << "X" <<endl;
				cout << "First Name : " <<  "X"<<endl;
				cout << "Zip Code : " << "X"  <<endl;	
			}
			else{
				cout << endl << "Last Name : " << lname <<endl;
				cout << "First Name : " << fname <<endl;
				cout << "Zip Code : " << zcode  <<endl;
			}
		}
};
//******************************************************************************************
//Funtion main
//******************************************************************************************
int main(){
	
Person p1, p2("Rijal","Promise", "44600");				//Define two objects of class
	p1.display();										//Display first object's data
	p2.display();										//Display second object's data
return 0;
}
