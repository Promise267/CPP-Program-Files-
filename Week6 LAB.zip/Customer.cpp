#include<iostream>
#include<string>
using namespace std;
//*****************************************************************************************************************************
//Name class declaration
//*****************************************************************************************************************************
class Name{
	
	private:
		
		string first;
		string middle;
		string last;
		
	public:
		
		Name(string, string, string);
		void displayFullName();
};
//*****************************************************************************************************************************
// parameterised constructor used to assign value to private data memebers of class Name indirectly by using arguments
//*****************************************************************************************************************************
Name::Name(string first , string middle, string last)
	{
		this->first = first;		// -> is used to access member variable
		this->middle = middle;
		this->last = last;
	}
//*****************************************************************************************************************************
//display function
//*****************************************************************************************************************************
void Name::displayFullName()
	{
		cout << first << "" << middle << "" << last << endl;
	}
//*****************************************************************************************************************************
//credit class declararion
//*****************************************************************************************************************************
class CreditData
{
	private:
		double currentBalance;
		double maxBalance;
	public:
		CreditData(double, double = 0);
		void displayCreditData();
};
//*****************************************************************************************************************************
// parameterised constructor used to assign value to private data memebers of class CreditData indirectly by using arguments
//*****************************************************************************************************************************
CreditData::CreditData(double currBal, double maxBal)
{
	currentBalance = currBal;
	if (maxBal < currBal)
		maxBalance = maxBal;
	else
		maxBalance = maxBal;
}
//*****************************************************************************************************************************
// disply function
//*****************************************************************************************************************************
void CreditData::displayCreditData()

{
	double creditLeft = maxBalance - currentBalance;
	cout << "Current Balance : $" << currentBalance<< "\nMaximum balance $" << maxBalance << "\nCredit left: $" << creditLeft << endl;
}
//*****************************************************************************************************************************
//customer class declararion
//*****************************************************************************************************************************
class Customer{
	private:
		Name name;
		CreditData credit;
		string phoneNumber;
	public:
		Customer(string, string ,string, double, double, string);
		void showCustomer();
};
//*****************************************************************************************************************************
// parameterised constructor is used to assign value to private data memebers of class Customer indirectly by using arguments
//*****************************************************************************************************************************
Customer::Customer(string firstName, string middleName, string lastName, double bal, double max, string phone) : name(firstName, middleName, lastName), credit(bal, max)
{
	phoneNumber = phone;
}
//*****************************************************************************************************************************
// display function
//*****************************************************************************************************************************
void Customer::showCustomer()
{
	cout << "Customer Data : " <<endl;
	name.displayFullName();
	cout << phoneNumber <<endl;
	credit.displayCreditData();
}
//*****************************************************************************************************************************
//function main
//*****************************************************************************************************************************
int main()
{
	int x;
	const int TIMES = 2;															
	string first, middle, last, phone;
	double bal, lim;
	for(x = 0; x < TIMES; ++x)														 //Repeats maximum of two times for the user to input
	{
		cout << endl << "Please enter first name for customer #" << (x + 1) << "  "; //Get Customers Data from the user
		cin >> first;
		cout << "Please enter middle name ";
		cin >> first;
		cout << "Please enter last name ";
		cin >> last;
		cout << "Enter current balance ";
		cin >>bal;
		cout << "Enter credit limit ";
		cin >> lim;
		cout << "Enter phone number ";
		cin >> phone;
		Customer cust(first, middle ,last, bal, lim, phone);
		cust.showCustomer();
	}
}
