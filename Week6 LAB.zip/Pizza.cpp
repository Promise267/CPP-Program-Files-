#include<iostream>
#include<string>
using namespace std;
// Pizza Class Declaration
class Pizza{

	private:
		
		string topping;
		int diameter;
		double price;
		const static string STDTOP;
		const static int STDSIZE;
		const static double STDPRICE;
		
	public:
		
		Pizza(const string = STDTOP, const int = STDSIZE , const double = STDPRICE);
		void setValues();
		void displayValues();
};

//*****************************************************************************************************************************
// static data member's values declared outside the class
//*****************************************************************************************************************************
const string Pizza::STDTOP = "cheese";
const int Pizza::STDSIZE = 12;
const double Pizza::STDPRICE = 8.99;

//*****************************************************************************************************************************
// parameterised constructor is used to assign value to private data memebers of class Customer indirectly by using arguments
//*****************************************************************************************************************************
Pizza::Pizza(const string top, const int size, const double price)
{
	topping = top;
	diameter = size;
	this->price = price;
}

//*****************************************************************************************************************************
// display function
//*****************************************************************************************************************************
void Pizza::displayValues()
{
	cout << "a " << diameter << " inch " << topping << " pizza. Price $" << price <<endl; 
}

//*****************************************************************************************************************************
// setValue which implements the conditions before it assigns value to the private data members and forwards to the display functions
//*****************************************************************************************************************************
void Pizza::setValues(){
	const double TOPPINGPREMIUM = 1.00;
	const double SIZEPREMIUM = 1.50;
		cout << "Enter Topping ";
		cin >> topping;
		if(topping != topping)
			price = STDPRICE + TOPPINGPREMIUM;
		cout << "Enter Size ";
		cin >> diameter;
		if (diameter > STDSIZE)
		price+= SIZEPREMIUM;
}

//*****************************************************************************************************************************
//function main
//*****************************************************************************************************************************
int main()
{
	Pizza aPizza;
	char standard;
	cout << "The standard pizza is: ";
	aPizza.displayValues();
	cout << "Let me take your orders" << endl;
	cout << "Do you want the standard pizza - y or no? ";				//taking input from user
	cin >> standard;													//stroes the input from user
	if(standard != 'y')
		aPizza.setValues();												//display function called by object
	cout << "Your order is ";
	aPizza.displayValues();												//display function called by object
	return 0;
}



