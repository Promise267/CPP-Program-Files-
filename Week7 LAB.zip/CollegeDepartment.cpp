#include <iostream>
using namespace std;
//Creating class named CollegeDepartment
class CollegeDepartment
{
    public:
        string departmentName;			//Variable declared to store department name
        string departmentChair;			//Variable declared to store department chair name
        int noOfClasses;				//Variable declared to store number of courses provided
        string * courseName=NULL;		//Pointers declared

CollegeDepartment()			//Default constructor created
		{
departmentName="Default Department";
departmentChair="Default Department Chair";
noOfClasses=10;
        }
CollegeDepartment(string depName, string depChair, int num)			//Parameterized constructor created
		{
departmentChair=depChair;
departmentName= depName;
noOfClasses= num;
        }
        friend ostream& operator << (ostream&out, const CollegeDepartment&c);
        friend istream& operator >> (istream&in, CollegeDepartment&c);

        bool operator <(const CollegeDepartment&d) 	//< operator overloaded
		{
if(noOfClasses<d.noOfClasses) {
                return true;
            }
if(noOfClasses == d.noOfClasses) {
                return true;
            }

            return false;
        }

CollegeDepartment& operator= (const CollegeDepartment&department);          
};
ostream& operator << (ostream&out, const CollegeDepartment&c)		//Extraction operator overloaded
{
	out<<"--------------------------------------------"<<endl;
    out<<"Department Name: "<<c.departmentName<<endl;
    out<< "Department Chair Name: "<<c.departmentChair<<endl;
    out<< "No of class in Department: "<<c.noOfClasses<<endl;
    out<<"--------------------------------------------"<<endl;
    return out;
}

istream& operator >> (istream&in, CollegeDepartment&c)		//Insertion operator overloaded
{
	cout<<"--------------------------------------------"<<endl;
cout<< "Enter the department name: ";
    in >>c.departmentName;
cout<< "Enter the department chair name: ";
    in >>c.departmentChair;
cout<< "Enter the no of courses: ";
    in >>c.noOfClasses;
cout<<"--------------------------------------------"<<endl;
    return in;
}
CollegeDepartment&CollegeDepartment::operator= (const CollegeDepartment&department)	//operator= overloaded
{
departmentName= department.departmentName;
departmentChair= department.departmentChair;
noOfClasses= department.noOfClasses;
    return *this;
}

/*
Function Main
*/
int main()
{
	int num;
	cout<< "How many department's data you want to enter?" <<endl;
	cin>> num;
	CollegeDepartment dep[num];
	for(int i=0; i<num; i++)
	{
		cin>> dep[i];
	}
	cout<< "The department details are: "<<endl;
	for(int i=0; i<num; i++)
	{
		cout<< dep[i];
	}
cout<< "Assignning  dep1 to dep2" <<endl;
dep[0]= dep[1];
cout<<dep[1].departmentName<< " has been assigned to "<< "dep1"<<endl;
cout<<dep[0];
    return 0;
}

