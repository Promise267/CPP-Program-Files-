#include<iostream>
using namespace std;

class Meal{
	
	private:
	
		string entree;
		int calorie;
		
	public:
		
		Meal(){
			entree = '\0';
			calorie = 0;
		}
		
	friend istream &operator >>(istream &in, Meal &m);
	friend ostream &operator <<(ostream &out, Meal &m);
	
	Meal operator +(Meal m);
};

Meal Meal::operator +(Meal m){
	Meal temp;
	temp.calorie = calorie + m.calorie;
	return temp;  
}

istream &operator >>(istream &in, Meal &m){
	cout << "\nEnter Name Of Entree = ";
	in >> m.entree;
	cout << "Enter Calorie Count = ";
	in >> m.calorie;
	return in;
}


ostream &operator <<(ostream &out, Meal &m){
	out << "\nDaily Total = " << m.calorie;
	return out;
}

	
	
int main()
{
	Meal breakfast;
	cin >> breakfast;
	
	Meal lunch;
	cin >> lunch;
	
	Meal dinner;
	cin >> dinner;
	
	Meal total;
	total = breakfast + lunch + dinner;
	cout << total;
	
	return 0;
}
