#include<iostream>
using namespace std;

class Meal{
	
	private:
	
		string entree;
		int calorie;
		
	public:
		
		Meal(){
			entree = '\0';
			calorie = 0;
		}
		
	friend istream &operator >>(istream &in, Meal &m);
	friend ostream &operator <<(ostream &out, Meal &m);
	Meal operator +(Meal);
};

istream &operator >>(istream &in, Meal &m){
	cout << "\nEnter Name Of Entree = ";
	in >> m.entree;
	cout << "Enter Calorie Count = ";
	in >> m.calorie;
	return in;
}


ostream &operator <<(ostream &out, Meal &m){
	out << "\nWeekly Total = " << m.calorie;
	return out;
}
	
Meal Meal::operator +(Meal m){
	Meal temp;
	temp.calorie = calorie + m.calorie;
	return temp;
}
int main(){

	int mealnum;
	cout<< "Enter number of meal entree?" <<endl;
	cin>>mealnum;
	Meal meal[mealnum];
	cout<< "Enter data for " <<mealnum<< " meals of the week: " <<endl;
	for(int i=0; i<mealnum; i++)
	{
		cin>> meal[i];
	}
	Meal weekTotal;
	for(int i=0; i<mealnum; i++)
	{
		weekTotal = weekTotal + meal[i];
	}
	cout<<weekTotal;
	return 0;
}

