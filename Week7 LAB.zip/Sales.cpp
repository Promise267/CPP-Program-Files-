#include<iostream>
#include<string>
using namespace std;

//Creating class named Salesperson and Sale
class Salesperson;
class Sale
{
	private:
		int dayofMonth;		//day of the month
		int amountSale;		//amount of the sale
		int idNo;			//  thesaleperson;s ID number
	public:
		Sale(int date, int amount, int id);
		friend void display(Salesperson saler, Sale sale);		
};
Sale::Sale(int date, int amount, int id)
{
	if(date>0 && date<32)
	{
		dayofMonth=date;
	}
	else
	{
		dayofMonth=1;
	} 
	amountSale=amount>0?amount:0;
	idNo=id;
}
class Salesperson
{
	private:
		string name;		//last name of saler
		int idNo;			//the salesperson's ID number
	public:
		Salesperson(string name, int id);
		friend void display(Salesperson saler, Sale sale);
};
Salesperson::Salesperson(string Name, int id)
{
	name=Name;
	idNo=id;
}
void display(Salesperson saler, Sale sale)
{
	cout<<"Date of sale:"<<sale.dayofMonth<<endl;
	cout<<"Amount:" <<sale.amountSale<<endl;
	cout<<"Saler:" << saler.name <<endl<<"ID:"<<saler.idNo<<endl;
}
//*******************************************************************
//Function Main                                                     *
//******************************************************************* 
int main()
{
	Sale s(03,500,6017);
	Salesperson sp("Rijal",7118);
	display(sp,s);
	return 0;
}

