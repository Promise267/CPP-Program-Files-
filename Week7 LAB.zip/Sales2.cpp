#include<iostream>
#include<string>
using namespace std;

//Creating class named Salesperson and Sale
class Salesperson;
class Sale
{
	private:
		int dayofMonth;		//day of the month
		double amountSale;		//amount of the sale
		int idNo;			//the saleperson's ID number
	public:
		Sale(int date, double amount, int id);
		int getID()
		{
			return idNo;
		}
		friend void display(Salesperson saler, Sale sale);
};
Sale::Sale(int date, double amount, int id)
{
	if(date>0 && date<32)
	{
		dayofMonth=date;
	}
	else
	{
		dayofMonth=1;
	} 
	amountSale=amount>0?amount:0;
	idNo=id;
}
class Salesperson
{
	private:
		string name;		//last name of saler
		int idNo;			//the salesperson's ID number
	public:
		Salesperson(string name, int id);
		int getID()
		{
			return idNo;
		}
		friend void display(Salesperson saler, Sale sale);
};
Salesperson::Salesperson(string Name, int id)
{
	name=Name;
	idNo=id;
}
void display(Salesperson saler, Sale sale)
{
	cout<<"-------------------------------------------"<<endl;
	cout<<"Date of sale: "<<sale.dayofMonth<<endl;
	cout<<"Amount: " <<sale.amountSale<<endl;
	cout<<"Saler: " << saler.name <<endl;
	cout<<"ID:"<<saler.idNo<<endl;
	cout<<"-------------------------------------------"<<endl;
}
//*******************************************************************
//Function Main                                                     *
//******************************************************************* 
int main()
{
	Salesperson persons[5]={
		Salesperson("Manandhar",101),
		Salesperson("Shakya",102),
		Salesperson("Yadav",103),
		Salesperson("Shrestha",104),
		Salesperson("Lama",105)
	};
	int count = 0, choice = 1;
	cout<< "Enter Sales Data: " <<endl;
	label1:
	if(choice==1)
	{
		//Read Data
		int dayofMonth;
		double amount;
		int ID;
		cout<<"Day of month: ";
		cin>>dayofMonth;
		cout<<"Amount: ";
		cin>>amount;
		cout<<"Sales person ID: ";
		cin>>ID;
		Sale sales(dayofMonth, amount, ID);
		
		bool valid = false;
		for (int i=0; i<5; i++){
			if(sales.getID() == persons[i].getID())
			{
				valid = true;
				count++;
				break;
			}
		}
		if(!valid)
		{
			cout<< "Invalid sales record. SalesPerson ID not found" <<endl;
		}
		else
		{
			if(sales.getID()==101)
				display(persons[0],sales);
			else if(sales.getID()==102)
				display(persons[1],sales);
			else if(sales.getID()==103)
				display(persons[2],sales);
			else if(sales.getID()==104)
				display(persons[3],sales);
			else
				display(persons[5],sales);
		}
		label2:
		if(count<5)
		{
			cout<< "Do you want to enter new sales? (Yes --> 1 / No --> 0): ";
			cin>> choice;
			if(choice==1)
			{
				goto label1;
			}
			else if(choice==0)
			{
				cout<< "Terminating program..." <<endl;
				goto label3;
			}
		}
	}
	label3:
	return 0;
}

