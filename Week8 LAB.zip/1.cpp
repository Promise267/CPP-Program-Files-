#include<iostream>
using namespace std;
class A{							//declaration of class A
	protected:						//protected access modifier so variable inside it is accessed throughout the class only and to the inherited class.
		int x;
	public:
		A(){
			x = 5;
		}
};

class B: public A{					//declaration of class B inherited from class A where class A's contents are public to class B
	public:
		void display(){				//display function
			cout << "x = " << x;	
		}
};

int main(){
	B b;							//define an instance of b class
	b.display();					//display function called
	return 0;
}



