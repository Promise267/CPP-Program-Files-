#include<iostream>
using namespace std;
class A{							//declaration of class A
	protected:						//protected access modifier so variable inside it is accessed throughout the class only and to the inherited class.
		int x;
	public:
		A(){
			x = 5;
		}
};

class B{					//declaration of class B inherited from class A where class A's contents are public to class B
	public:
		int y;				
	public:
		B(){
			y = 3;
		}
};

class C : public A, public B{		//declaration of class C inherited from class A and B where class A and B's contents are public to class C
	public:
		void display(){					//display function
			cout << "x = " << x;
			cout << "\ny = " << y;
		}
};

int main(){
	C c;							//define an instance of C class
	c.display();					//display function called
	return 0;
}



