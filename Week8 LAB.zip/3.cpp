#include <iostream>
using namespace std;
class A //single base class A
{
 	public:
 		
		 int x;
 	
 		void getx(){
    		cout << "Enter value of x= "; 
			cin >> x;
 		}
};

class B : public A // derived class from base class A
{
 	public:
 	
		int y;
 	
 	void gety(){
 		cout << "\nEnter value of y= "; 
		cin >> y;
 		}
};

class C : public B   // derived from class B
{
 	private:
 	
		int z;
 	
	public:
 	
		void getz(){
    		cout << "\nEnter value of z= ";
			cin >> z;
 		}
 		
 		void product(){
 	    	cout << "\nProduct= " << x * y * z;
 		}
};

int main(){
     C c;      //object of derived class
     c.getx();
     c.gety();
     c.getz();
     c.product();
     return 0;
}        
