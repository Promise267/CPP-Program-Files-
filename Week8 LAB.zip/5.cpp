#include <iostream> 
using namespace std;

class A{ //single base class
    public:
 		int x, y;
 	
 		A(){
 			x = 7;
 			y = 3;
	 	};
	 
};
class B : public A{ //B is derived from class base
    public:
 		void sum(){
        	cout << "\nSum= " << x + y;
 		}
};
class C : public A{ //C is also derived from class base
    public:
		void diff(){
			cout << "\nDifference = " << x - y;
		}
};

class D : public A{ //D is also derived from class base
	public:
 		void product(){
 	    	cout << "\nProduct= " << x * y;
 		}
};

int main()
{
    B b;          //object of derived class B
    C c;          //object of derived class C
    D d;		  //object of derived class D
    b.sum();
    c.diff();
    d.product();
    
    return 0;
}
