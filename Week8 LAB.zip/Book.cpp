#include<iostream>
using namespace std;
class Book{
	protected:
		
		string title;
		string author;
		
	public:
		
		Book(string Title, string Author){
			title = Title;
			author = Author;
		}
		
		void setTitle(string newTitle){
			title=newTitle;
		}
		
		void setAuthor(string newAuthor){
			author=newAuthor;
		}
		
		void display(){
			cout<<"\nTitle = "<<title<<endl; 
			cout<<"Author = "<<author<<endl;
		}
};
class Fiction: public Book{
	
	private:
		
		int level;
		
	public:
		
		Fiction(string Title, string Author,int Level): Book(Title, Author){
			level=Level;
		}
		
		void setLevel(int Level){
			level=Level;
		}
		
		void display(){
			Book::display();
			cout<<"Numeric grade reading level = "<<level<<endl;
		}
};

class NonFiction:public Book
{
	private:
		
		int numbersPages;
		
	public:
		
		NonFiction(string Title, string Author, int number): Book(Title,Author){
			numbersPages=number;
		}
		
		void setNumber(int Number){
			numbersPages=Number;
		}
		
		void display() {
			Book::display();
			cout<<"Number of pages = "<<numbersPages<<endl;
		}
};

int main(){
	
	Book first("Rich Dad Poor Dad","Robert T Kiyosaki"); 
	Fiction second("Algebra","Pythagoras",3);
	NonFiction third("Alice in Wonderland","Lewis Carroll",150);
	
	cout<<"\nBook:"<<endl;
	first.display();

	cout<<"\n\n=================================================================================================================================="<<endl;
	cout<<"\nFiction book:"<<endl;
	second.display();
	
	cout<<"\n\n=================================================================================================================================="<<endl;
	cout<<"\nNonFiction book:"<<endl;
	third.display();
	
return 0;
}
